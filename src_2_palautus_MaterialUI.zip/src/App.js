import React from 'react';
import CreateRecipe from './components/CreateRecipe';
import ViewRecipe from './components/ViewRecipe';
import RecipeItem from './components/RecipeItem';
import SearchRecipe from './components/SearchRecipes';
import FrontPage from './components/FrontPage';
import './App.css';
import BookMenu from './navigation/menu';
import Tabs from './navigation/tabs';
import {red, purple, blue, green, yellow, blueGrey } from '@mui/material/colors';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';



const theme = createTheme({
  palette: { primary: {main: '#864000', 
    contrastText: '#FFEFCF'},    
    secondary: {main: '#FF7A00', 
      contrastText: '#FFEFCF'},    
      text: {primary: '#D44000', 
        secondary: blueGrey[900], 
        contrastText: '#FFEFCF'},    
        action: {hover:  blueGrey[100]},    
        background: {default: '#FFEFCF'} },
        
        typography: { fontFamily: ['Sriracha', 'cursive'], },
        
        overrides: {  },

        
      
      });


  

const recipes = [

  {
    id: 1,
    
  nimi: 'Mustikkamuffinssit',
  kategoria: 'Leivonnainen',
  ainekset: '1 dl Mustikoita; 2 dl jauhoja; 2 kpl kananmunia',
  ohje: 'Tee muffinssit',
  arvostelut: 2,
  tahdet: 8,
  picture:  "./photos/blueberrymuffins.jpg"},

  { 
    id: 2,
   
  nimi: 'Banaanipannukakku',
  kategoria: 'Välipala',
  ainekset: '2 kpl banaaneja; 2 kpl kananmunia',
  ohje: 'Tee pannukakku',
  arvostelut: 3,
  tahdet: 9,
  picture:  "./photos/bananapancake.jpg"}
];

function App() {

  return(

    <ThemeProvider theme={ theme }>
  <div>
  <CssBaseline />
  <BookMenu />
  <Tabs />
   <CreateRecipe />
    <ViewRecipe recipes={ recipes }/>
    <RecipeItem recipes={ recipes } />
    <SearchRecipe />
    <FrontPage />

   
    </div>
</ThemeProvider>

   
  );
}

export default App;

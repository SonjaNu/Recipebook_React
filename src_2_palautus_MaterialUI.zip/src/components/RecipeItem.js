import React, {useState} from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import CardActions from '@mui/material/CardActions';
import DeleteIcon from '@mui/icons-material/Delete';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import Button from '@mui/material/Button';
import FormLabel from '@mui/material/FormLabel';
import Paper from '@mui/material/Paper';
import Rating from '@mui/material/Rating';



function RecipeItem (props) {
    const [value, setValue] = React.useState(2);

    return (
        <Paper sx={ {marginTop: 2, marginLeft: 2, padding: 2} }>
        <form>

        <FormLabel sx={{ color: 'text.primary', fontSize: 34, fontWeight: 'medium' }}> Yhden reseptin tiedot</FormLabel>


        <Box
      sx={{
        '& > legend': { mt: 2 },
      }}
    >
      <Typography component="legend">Arvostele resepti</Typography>
      <Rating
        name="simple-controlled"
        value={value}
        onChange={(event, newValue) => {
          setValue(newValue);
        }}
      />
      <Typography component="legend">Reseptin keräämät tähdet</Typography>
      <Rating name="read-only" value={value} readOnly />
     
      <Typography component="legend">No rating given</Typography>
      <Rating name="no-value" value={null} />
    </Box>

        

        </form>
        </Paper>
    )
}


export default RecipeItem;
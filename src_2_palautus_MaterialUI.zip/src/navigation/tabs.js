import React, { useState } from 'react';
import Box from '@mui/material/Box'
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import HomeIcon from '@mui/icons-material/Home';
import CreateIcon from '@mui/icons-material/Create';
import ListIcon from '@mui/icons-material/List';

import BrightnessLowIcon from '@mui/icons-material/BrightnessLow';
import CreateRecipe from '../components/CreateRecipe';
import RecipeItem from '../components/RecipeItem';
import ViewRecipe from '../components/ViewRecipe';
import SearchIcon from '@mui/icons-material/Search';
import StarIcon from '@mui/icons-material/Star';


function TabIcons (props) {

  const [value, setValue] = useState(0);

  const handleChange = (e, val) => {
    setValue(val);
  }

  return (
    <Box>
        <Tabs value={ value } onChange={ handleChange } variant='fullWidth' centered>
          <Tab label='Etusivu' icon={ <HomeIcon /> } />
          <Tab label='Lisää resepti' icon={ <CreateIcon /> }/>
          <Tab label='Näytä reseptit' icon={ <ListIcon /> } />
          <Tab label='Reseptihaku' icon={ <SearchIcon /> } />
          <Tab label='Inspiroidu' icon={ <BrightnessLowIcon /> } />
          <Tab label='Suosikkireseptit' icon={ <StarIcon /> } />
          
          
          
        </Tabs>
    
     
    </Box>
  );
}

export default TabIcons;